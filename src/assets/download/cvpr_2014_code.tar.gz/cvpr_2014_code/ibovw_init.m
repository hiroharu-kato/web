ibovw_dataset_resize();
ibovw_dataset_make_imagelist();
ibovw_make_descriptor_database();
ibovw_pca_descriptors;
ibovw_invertdescriptor_make_Z();
ibovw_invertdescriptor_make_UV();
ibovw_make_visualwords();
ibovw_make_quantized_descriptor_database();
ibovw_make_bovw_database();
ibovw_make_adjacent_cost();
ibovw_make_position_cost();

