function [] = ibovw_invertdescriptor_make_Z()
	% make Z for parametes to invert descriptor
	% Z(ROW,:) = [IMAGE(:), DESCRIPTOR(:)]

	settings = ibovw_settings();

	imagelist = getfield(load(settings.invertdescriptor.imagelist), 'imagelist');
	pca = load(settings.descriptor.filename_pca);

	Z = {};

	parfor j=1:size(imagelist,2)
		img = imread([settings.dataset.directory, imagelist{j}]);
		descriptors = ibovw_extract_descriptors(img);
		descriptors = descriptors*pca.coeff;
		descriptors = descriptors(:, 1:pca.dim);

		if settings.descriptor.color
			if ndims(img) == 2
				img = repmat(img, [1,1,3]);
			end
			images = zeros(settings.descriptor.num, 3*settings.descriptor.patchsize^2);
		else
			if ndims(img) == 3
				img = rgb2gray(img);
			end
			images = zeros(settings.descriptor.num, settings.descriptor.patchsize^2);
		end

		for i = 1:size(descriptors, 1)
			y = mod((i-1),settings.descriptor.ymax)+1;
			x = floor((i-1)/settings.descriptor.ymax)+1;
			ymax = min((y-1)*settings.descriptor.step+settings.descriptor.patchsize, size(img,1));
			xmax = min((x-1)*settings.descriptor.step+settings.descriptor.patchsize, size(img,2));
			ymin = ymax-settings.descriptor.patchsize+1;
			xmin = xmax-settings.descriptor.patchsize+1;
			if settings.descriptor.color
				img_small = img(ymin:ymax, xmin:xmax, :);
			else
				img_small = img(ymin:ymax, xmin:xmax);
			end
			img_small = reshape(img_small, 1, numel(img_small));
			images(i,:) = img_small;
		end
		Z{j} = [images, descriptors];
	end

	Z = cell2mat(Z');
	save(settings.invertdescriptor.filename_Z, 'Z', '-v7.3');
end
