function ibovw_make_quantized_descriptor_database()
	settings = ibovw_settings();

	imagelist = getfield(load(settings.quantized_descriptor_database.imagelist), 'imagelist');
	pca = load(settings.descriptor.filename_pca);

	for j=1:size(settings.visualword.nums, 2)
		descriptor_database = uint32(zeros(size(imagelist,2), settings.descriptor.num));
		visualwords = getfield(load(settings.visualword.filename{j}), 'visualwords');
		
		parfor i=1:size(imagelist,2)
			filename = [settings.dataset.directory, imagelist{i}];

			image = imread(filename);
			descriptors = ibovw_extract_descriptors(image);
			descriptors = descriptors*pca.coeff;
			descriptors = descriptors(:, 1:pca.dim);
			descriptors = ibovw_quantize_descriptors(descriptors, visualwords);
			descriptor_database(i, :) = descriptors;
		end

		save(settings.quantized_descriptor_database.filename{j}, 'descriptor_database', '-v7.3');
	end
end
