function [bovw, codenumbers] = ibovw_extract_bovw(img, k)
	settings = ibovw_settings();
	visualwords = getfield(load(settings.visualword.filename{find(settings.visualword.nums==k)}), 'visualwords');
	pca = load(settings.descriptor.filename_pca);

	d = ibovw_extract_descriptors(img);
	d = d * pca.coeff;
	d = d(:,1:pca.dim);
	d = ibovw_quantize_descriptors(d, visualwords);
	codenumbers = d';
	bovw = histc(d, 1:k)';
end
