function [] = ibovw_make_bovw_database()
	settings = ibovw_settings();

	for i=1:size(settings.visualword.nums, 2)
		data = getfield(load(settings.quantized_descriptor_database.filename{i}),'descriptor_database');
		
		bovw_database = uint8(histc(data, 1:settings.visualword.nums(i), 2));
		save(settings.bovw_database.filename{i}, 'bovw_database', '-v7.3');
	end
end
