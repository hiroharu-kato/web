[About]
This code is based on our CVPR '14 paper "image reconstruction from bag-of-visual-words". By this code you can reproduce results of all experiments shown in the paper. However it contains some small modifications about hyper-parameters and the way to compute global location cost.

@InProceedings{Kato_CVPR_2014,
    author = {Hiroharu Kato and Tatsuya Harada},
    title = {Image Reconstruction from Bag-of-Visual-Words},
    booktitle = {The IEEE Conference on Computer Vision and Pattern Recognition (CVPR)},
    year = {2014}
}


[Pre-requisites]
It requires following libraries:
    LabelMe Toolbox http://labelme.csail.mit.edu/Release3.0/browserTools/php/matlab_toolbox.php
    Yael https://gforge.inria.fr/projects/yael/
    SPAMS http://spams-devel.gforge.inria.fr/
    LIBSVM http://www.csie.ntu.edu.tw/~cjlin/libsvm/

It also requires ILSVRC 2012 dataset.
http://www.image-net.org/challenges/LSVRC/2012/

They must be placed at ./external directory.


[Sample code]
% compute adjacent / global location cost
ibovw_init();
 
% load settings
settings = ibovw_settings();
k = settings.visualword.nums(end);
img_size = settings.image.size;

% extract bovw
img = imread('test.jpg');
img = imresize(img, img_size);
[~, bovw] = ibovw_extract_bovw(img, k);

% reconstruction
reconstructor = ibovw_reconstructor_new(k);
img2 = ibovw_reconstructor_reconstruct(reconstructor, bovw);

% reproduce experiments
ibovw_experiment1();
ibovw_experiment2();
ibovw_experiment3();
ibovw_experiment4();
ibovw_experiment5();
ibovw_experiment6();
ibovw_experiment7();
ibovw_experiment8();
ibovw_experiment9();


[About adjacent / global location cost]
Pre-computed parameter files are not included in this archive because they are too large (about 10GB). By them you can skip ibovw_init() which requires large dataset and much computation cost. If you need parameter files please contact me.


[Contact]
If you have any questions, please feel free to contact me.
Mail: hiroharu.kato.1989.10.13@gmail.com
Website: http://hiroharu-kato.com/
