function [score] = rc_score_direct(jigsaw_test, jigsaw_correct)
	score = sum(jigsaw_test==jigsaw_correct) / numel(jigsaw_test);
end
