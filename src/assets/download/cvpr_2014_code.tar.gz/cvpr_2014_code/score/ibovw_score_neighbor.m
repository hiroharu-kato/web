function [score] = ibovw_score_neighbor(jigsaw_test, jigsaw_correct)
	jigsaw_test = reshape(jigsaw_test, 13, 13);
	jigsaw_correct = reshape(jigsaw_correct, 13 ,13);
	
	true_count = 0;

	test_list = [];
	correct_list = [];
	for x=1:13; for y=1:12;
		test_list = [reshape(jigsaw_test(y:y+1,x), 1, []); test_list];
		correct_list = [reshape(jigsaw_correct(y:y+1,x), 1, []); correct_list];
	end; end;

	for i=1:size(test_list,1)
		[~,idx] = ismember(test_list(i,:),correct_list,'rows');
		if idx>0
			correct_list(idx,:) = [];
		end
	end;
	true_count = true_count + size(test_list,1) - size(correct_list,1);

	test_list = [];
	correct_list = [];
	for x=1:12; for y=1:13;
		test_list = [reshape(jigsaw_test(y,x:x+1), 1, []); test_list];
		correct_list = [reshape(jigsaw_correct(y,x:x+1), 1, []); correct_list];
	end; end;

	for i=1:size(test_list,1)
		[~,idx] = ismember(test_list(i,:),correct_list,'rows');
		if idx>0
			correct_list(idx,:) = [];
		end
	end;
	true_count = true_count + size(test_list,1) - size(correct_list,1);
	
	score = true_count / (2*13*12);
end
