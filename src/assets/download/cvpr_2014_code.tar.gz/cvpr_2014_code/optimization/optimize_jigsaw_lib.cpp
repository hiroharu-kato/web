#include <iostream>
#include <climits>
#include <algorithm>
#include <numeric>
#include <random>
#include <memory>
#include "optimize_jigsaw_lib.hpp"

using namespace std;

/* getter functions */
inline int get_from_jigsaw(Jigsaw jigsaw, int n);
inline int get_from_jigsaw(Jigsaw jigsaw, int y, int x);
inline void set_to_jigsaw(Jigsaw jigsaw, int n, int value);
inline void set_to_jigsaw(Jigsaw jigsaw, int y, int x, int value);
inline float get_index_from_yshift_xshift(int yshift, int xshift);
inline float get_from_adjacent_cost(AdjacentCost adjacent_cost, int num1, int num2, int shift_index);
inline float get_from_adjacent_cost(AdjacentCost adjacent_cost, int num1, int num2, int yshift, int xshift);
inline float get_from_location_cost(LocationCost location_cost, int num, int pos);

/* cost computation functions */
float compute_cost(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost);
float compute_swap_cost(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost, int pos1, int pos2);
float compute_swap_cost(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost, int y1, int x1, int y2, int x2);

/* optimization functions */
float hill_climbing(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost);
float hill_climbing2(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost);
float simulated_annealing(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost);
float hybrid_genetic_algorithm(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost);

/* neighborhood stores */
int neighbor_num[N];
int** neighbor_pos;
int** neighbor_shift_index;
int** neighbor_shift_rindex;

/* random generators */
mt19937 rng;
uniform_real_distribution<> rand_01;
uniform_int_distribution<> rand_n(0,N-1);


/* main function */
float optimize(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost, Method method){

    /* make initial jigsaw if not initialized */
    if (accumulate(jigsaw, jigsaw+N, 0) != N*(N-1)/2) {
        for (int i=0; i<N; ++i) set_to_jigsaw(jigsaw, i, i);
        shuffle(jigsaw);
    }


    /* make neighbor list */
    neighbor_pos = new int*[N];
    neighbor_shift_index = new int*[N];
    neighbor_shift_rindex = new int*[N];

    for (int i=0; i<N; ++i){
        neighbor_pos[i] = new int[7*7];
        neighbor_shift_index[i] = new int[7*7];
        neighbor_shift_rindex[i] = new int[7*7];

        int y1 = i % YMAX;
        int x1 = i / YMAX;
        int count = (min(y1+3+1,YMAX)-max(y1-3,0))*(min(x1+3+1,XMAX)-max(x1-3,0)) - 1;
        neighbor_num[i] = count;
        int j = 0;
        for (int y2=max(y1-3,0); y2<min(y1+3+1,YMAX); ++y2)
            for (int x2=max(x1-3,0); x2<min(x1+3+1,XMAX); ++x2) {
                if ((y2!=y1)||(x2!=x1)){
                    neighbor_pos[i][j] = y2+x2*YMAX;
                    neighbor_shift_index[i][j] = get_index_from_yshift_xshift(y2-y1,x2-x1);
                    neighbor_shift_rindex[i][j] = get_index_from_yshift_xshift(y1-y2,x1-x2);
                    j++;
                }
            }
    }

    /* optimize */
    float cost;
    switch(method){
        case NONE:
            cost = compute_cost(jigsaw, adjacent_cost, location_cost);
            break;
        case HILL_CLIMBING:
            cost = hill_climbing(jigsaw, adjacent_cost, location_cost);
            break;
        case HILL_CLIMBING2:
            cost = hill_climbing2(jigsaw, adjacent_cost, location_cost);
            break;
        case SIMULATED_ANNEALING:
            cost = simulated_annealing(jigsaw, adjacent_cost, location_cost);
            break;
        case HYBRID_GENETIC_ALGORITHM:
            cost = hybrid_genetic_algorithm(jigsaw, adjacent_cost, location_cost);
            break;
    }


    for (int i=0; i<N; ++i){
        delete [] neighbor_pos[i];
        delete [] neighbor_shift_index[i];
        delete [] neighbor_shift_rindex[i];
    }
    delete [] neighbor_pos;
    delete [] neighbor_shift_index;
    delete [] neighbor_shift_rindex;

    return cost;
}


/* getter functions */
inline int get_from_jigsaw(Jigsaw jigsaw, int n){
    return jigsaw[n];
}

inline int get_from_jigsaw(Jigsaw jigsaw, int y, int x){
    return jigsaw[y+x*YMAX];
}

inline void set_to_jigsaw(Jigsaw jigsaw, int n, int value){
    jigsaw[n] = value;
}

inline void set_to_jigsaw(Jigsaw jigsaw, int y, int x, int value){
    jigsaw[y+x*YMAX] = value;
}

inline float get_index_from_yshift_xshift(int yshift, int xshift){
    return (yshift+3)+(xshift+3)*7;
}

inline float get_from_adjacent_cost(AdjacentCost adjacent_cost, int num1, int num2, int shift_index){
    return adjacent_cost[num1+num2*N+shift_index*N*N];
}

inline float get_from_adjacent_cost(AdjacentCost adjacent_cost, int num1, int num2, int yshift, int xshift){
    return get_from_adjacent_cost(adjacent_cost, num1, num2, get_index_from_yshift_xshift(yshift, xshift));
}

inline float get_from_location_cost(LocationCost location_cost, int num, int pos){
    return location_cost[num+pos*N];
}


/* cost computation functions */
float compute_cost(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost){
    float cost = 0;
    int pos1, num1, num2, i;

    // adjacent cost
    for (pos1=0; pos1<N; ++pos1){
        num1 = get_from_jigsaw(jigsaw, pos1);
        for (i=0; i<neighbor_num[pos1]; ++i){
            num2 = get_from_jigsaw(jigsaw, neighbor_pos[pos1][i]);
            cost += get_from_adjacent_cost(adjacent_cost, num1, num2, neighbor_shift_index[pos1][i]);
        }
    }

    // location cost
    for (pos1=0; pos1<N; ++pos1){
        num1 = get_from_jigsaw(jigsaw, pos1);
        cost += get_from_location_cost(location_cost, num1, pos1);
    }

    return cost;
}

float compute_swap_cost(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost, int pos1, int pos2){
    float cost = 0;
    int num1 = get_from_jigsaw(jigsaw, pos1);
    int num2 = get_from_jigsaw(jigsaw, pos2);
    int i, shift, rshift;

    for (i=0; i<neighbor_num[pos1]; ++i){
        cost -= get_from_adjacent_cost(adjacent_cost, num1, get_from_jigsaw(jigsaw, neighbor_pos[pos1][i]), neighbor_shift_index[pos1][i]);
        cost -= get_from_adjacent_cost(adjacent_cost, get_from_jigsaw(jigsaw, neighbor_pos[pos1][i]), num1, neighbor_shift_rindex[pos1][i]);
        cost += get_from_adjacent_cost(adjacent_cost, num2, get_from_jigsaw(jigsaw, neighbor_pos[pos1][i]), neighbor_shift_index[pos1][i]);
        cost += get_from_adjacent_cost(adjacent_cost, get_from_jigsaw(jigsaw, neighbor_pos[pos1][i]), num2, neighbor_shift_rindex[pos1][i]);
    }

    for (i=0; i<neighbor_num[pos2]; ++i){
        cost -= get_from_adjacent_cost(adjacent_cost, num2, get_from_jigsaw(jigsaw, neighbor_pos[pos2][i]), neighbor_shift_index[pos2][i]);
        cost -= get_from_adjacent_cost(adjacent_cost, get_from_jigsaw(jigsaw, neighbor_pos[pos2][i]), num2, neighbor_shift_rindex[pos2][i]);
        cost += get_from_adjacent_cost(adjacent_cost, num1, get_from_jigsaw(jigsaw, neighbor_pos[pos2][i]), neighbor_shift_index[pos2][i]);
        cost += get_from_adjacent_cost(adjacent_cost, get_from_jigsaw(jigsaw, neighbor_pos[pos2][i]), num1, neighbor_shift_rindex[pos2][i]);
    }

    if (abs((pos1%YMAX)-(pos2%YMAX))<4 && abs((pos1/YMAX)-(pos2/YMAX))<4){
        shift = get_index_from_yshift_xshift(pos2%YMAX-pos1%YMAX,pos2/YMAX-pos1/YMAX);
        rshift = get_index_from_yshift_xshift(pos1%YMAX-pos2%YMAX,pos1/YMAX-pos2/YMAX);
        cost += get_from_adjacent_cost(adjacent_cost, num1, num2, shift);
        cost += get_from_adjacent_cost(adjacent_cost, num1, num2, rshift);
        cost += get_from_adjacent_cost(adjacent_cost, num2, num1, rshift);
        cost += get_from_adjacent_cost(adjacent_cost, num2, num1, shift);
        cost -= get_from_adjacent_cost(adjacent_cost, num1, num1, rshift);
        cost -= get_from_adjacent_cost(adjacent_cost, num1, num1, shift);
        cost -= get_from_adjacent_cost(adjacent_cost, num2, num2, shift);
        cost -= get_from_adjacent_cost(adjacent_cost, num2, num2, rshift);
    }

    cost -= get_from_location_cost(location_cost, num1, pos1);
    cost -= get_from_location_cost(location_cost, num2, pos2);
    cost += get_from_location_cost(location_cost, num1, pos2);
    cost += get_from_location_cost(location_cost, num2, pos1);

    return cost;
}

float compute_swap_cost(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost, int y1, int x1, int y2, int x2){
    return compute_swap_cost(jigsaw, adjacent_cost, location_cost, y1+x1*YMAX,y2+x2*YMAX);
}


/* jigsaw manipulation functions */
void swap(Jigsaw jigsaw, int pos1, int pos2){
    int num1 = get_from_jigsaw(jigsaw, pos1);
    int num2 = get_from_jigsaw(jigsaw, pos2);
    set_to_jigsaw(jigsaw, pos1, num2);
    set_to_jigsaw(jigsaw, pos2, num1);
}

void swap(Jigsaw jigsaw, int y1, int x1, int y2, int x2){
    swap(jigsaw, y1+x1*YMAX,y2+x2*YMAX);
}

void shuffle(Jigsaw jigsaw){
    random_shuffle(jigsaw, jigsaw+N);
}

void show_jigsaw(Jigsaw jigsaw){
    for (int y=0; y<YMAX; y++) {
        for (int x=0; x<XMAX; x++) {
            cout.width(log10(N)+2);
            cout << jigsaw[y+x*YMAX];
        }
        cout << endl;
    }
}


/* optimization fuctions */
float hill_climbing(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost){
    float diff, min_diff;
    int pos1, pos2, pos3, pos4, min_diff_pos1, min_diff_pos2;
    int num1, num2, num3, num4;
    int i, p3, p4, shift, rshift;
    float** diff_matrix;

    // initial diff_matrix
    diff_matrix = new float*[N];
    for (i=0; i<N; ++i) diff_matrix[i] = new float[N];
    for (pos1=0; pos1<N; ++pos1) for (pos2=pos1+1; pos2<N; ++pos2)
        diff_matrix[pos1][pos2] = compute_swap_cost(jigsaw, adjacent_cost, location_cost, pos1, pos2);

    while (true) {
        min_diff = 0;
        for (pos1=0; pos1<N; ++pos1) for (pos2=pos1+1; pos2<N; ++pos2)
            if (min_diff > diff_matrix[pos1][pos2]){
                min_diff = diff_matrix[pos1][pos2];
                min_diff_pos1 = pos1;
                min_diff_pos2 = pos2;
            }

        if (min_diff>-0.001) break;

        swap(jigsaw, min_diff_pos1, min_diff_pos2);

        pos1 = min_diff_pos1;
        pos2 = min_diff_pos2;
        num1 = get_from_jigsaw(jigsaw, pos2);
        num2 = get_from_jigsaw(jigsaw, pos1);

        for (i=0; i<neighbor_num[pos1]; ++i){
            pos3 = neighbor_pos[pos1][i];
            num3 = get_from_jigsaw(jigsaw, pos3);
            shift = get_index_from_yshift_xshift(pos3%YMAX-pos1%YMAX, pos3/YMAX-pos1/YMAX);
            rshift = get_index_from_yshift_xshift(pos1%YMAX-pos3%YMAX, pos1/YMAX-pos3/YMAX);
            for (pos4=0; pos4<N; ++pos4){
                if (pos4 == pos2 || pos4 == pos3) continue;
                num4 = get_from_jigsaw(jigsaw, pos4);
                p3 = min(pos3,pos4);
                p4 = max(pos3,pos4);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num2, num3, shift);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num3, num2, rshift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num2, num4, shift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num4, num2, rshift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num1, num3, shift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num3, num1, rshift);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num1, num4, shift);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num4, num1, rshift);
            }
        }

        for (i=0; i<neighbor_num[pos2]; ++i){
            pos3 = neighbor_pos[pos2][i];
            num3 = get_from_jigsaw(jigsaw, pos3);
            shift = get_index_from_yshift_xshift(pos3%YMAX-pos2%YMAX, pos3/YMAX-pos2/YMAX);
            rshift = get_index_from_yshift_xshift(pos2%YMAX-pos3%YMAX, pos2/YMAX-pos3/YMAX);
            for (pos4=0; pos4<N; ++pos4){
                if (pos4 == pos1 || pos4 == pos3) continue;
                num4 = get_from_jigsaw(jigsaw, pos4);
                p3 = min(pos3,pos4);
                p4 = max(pos3,pos4);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num1, num3, shift);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num3, num1, rshift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num1, num4, shift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num4, num1, rshift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num2, num3, shift);
                diff_matrix[p3][p4] += get_from_adjacent_cost(adjacent_cost, num3, num2, rshift);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num2, num4, shift);
                diff_matrix[p3][p4] -= get_from_adjacent_cost(adjacent_cost, num4, num2, rshift);
            }
        }

        for (pos3=0; pos3<N; ++pos3) for (pos4=pos3+1; pos4<N; ++pos4)
            if (pos3==pos1 || pos3==pos2 || pos4==pos1 || pos4==pos2)
                diff_matrix[pos3][pos4] = compute_swap_cost(jigsaw, adjacent_cost, location_cost, pos3, pos4);
    }

    for (i=0; i<N; ++i) delete [] diff_matrix[i];
    delete [] diff_matrix;

    return compute_cost(jigsaw, adjacent_cost, location_cost);
}

float hill_climbing2(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost){
    int i, pos1, pos2;
    for (i=0;i<5*pow(N, 2); ++i){
        pos1 = rand_n(rng);
        pos2 = rand_n(rng);
        if (compute_swap_cost(jigsaw, adjacent_cost, location_cost, pos1, pos2)<0) swap(jigsaw, pos1, pos2);
    }
    return compute_cost(jigsaw, adjacent_cost, location_cost);
}

float simulated_annealing(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost){
    float cost, cost_old, diff;
    int count, i, pos1, pos2;

    float t = 1;
    float k = 1000;
    float alpha = 0.99;

    while (true){
        cost_old = cost;
        for (i=0; i<N*10; ++i) {
            pos1 = rand_n(rng);
            pos2 = rand_n(rng);
            diff = compute_swap_cost(jigsaw, adjacent_cost, location_cost, pos1, pos2);
            if ((diff<0)||(exp(-diff/(k*t))>rand_01(rng))) swap(jigsaw, pos1, pos2);
        }

        cost = compute_cost(jigsaw, adjacent_cost, location_cost);
        if ((cost-cost_old)>0) t *= alpha;
        if (abs(cost-cost_old) < 0.01){
            count++;
            if (count>10) break;
        }else{
            count = 0;
        }
    }

    return cost;
}

float hybrid_genetic_algorithm(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost){
    int minindex, maxindex;

    int P = 100;
    int p = 0.2;

    Jigsaw* population = new Jigsaw[P];
    float* costs = new float[P];
    int* num_codeword = new int[N];
    int* unique_codewords = new int[N];
    int remain_list[N];

    // set codeword list
    for (int i=0; i<N; ++i) num_codeword[i] = get_from_jigsaw(jigsaw, i);
    sort(num_codeword, num_codeword+N);
    int unique_codewords_size = 0;
    for (int i=0; i<N; ++i){
        if (unique_codewords_size==0) {
            unique_codewords[unique_codewords_size] = num_codeword[unique_codewords_size];
            unique_codewords_size++;
        }else{
            if (num_codeword[i] != unique_codewords[unique_codewords_size-1]){
                unique_codewords[unique_codewords_size] = num_codeword[i];
                unique_codewords_size++;
            }
        }
    }

    // make populations
#pragma omp parallel for
    for (int i=0; i<P; ++i){
        population[i] = new int[N];
        for (int j=0;j<N;j++) set_to_jigsaw(population[i], j, j);
        shuffle(population[i]);
        costs[i] = hill_climbing(population[i], adjacent_cost, location_cost);
    }

    // for each generation
    for (int i=0; i<INT_MAX; ++i){
        Jigsaw firstparent = population[rand() % P];
        Jigsaw secondparent = population[rand() % P];
        if (firstparent == secondparent) continue;
        Jigsaw child = new int[N];

        int pivot_y = rand() % YMAX;
        int pivot_x = rand() % XMAX;
        float distm[N];
        bool realm1[N], realm2[N];
        float dist_mean = 0;
        for (int j=0; j<N; ++j) {
            distm[j] = sqrt(pow((j%YMAX)-pivot_y,2) + pow((j/YMAX)-pivot_x, 2));
            dist_mean += distm[j]/N;
        }

        for (int j=0; j<N; ++j){
            realm1[j] = (distm[j]<dist_mean);
            realm2[j] = (distm[j]>=dist_mean);
            child[j] = realm1[j] ? get_from_jigsaw(firstparent, j) : get_from_jigsaw(secondparent, j);
        }

        for (int j=0; j<unique_codewords_size; ++j){
            remain_list[j] = 0;
            int num = unique_codewords[j];
            int num_in_jigsaw = 0;
            int num_in_realm1 = 0;
            int num_in_realm2 = 0;
            for (int l=0; l<N; ++l){
                if (num_codeword[l]==num) num_in_jigsaw++;
                if (get_from_jigsaw(child, l) == num)
                   if (realm1[l]) num_in_realm1++; else num_in_realm2++;
            }
            int diff = num_in_jigsaw - (num_in_realm1+num_in_realm2);
            if (diff>=0) {
                remain_list[j] = diff;
            }else{
                for (int l=0; l<N; ++l){
                    if ((realm2[l])&&(get_from_jigsaw(child, l)==num)){
                        set_to_jigsaw(child, l, -1);
                        diff++;
                    }
                    if (diff==0) break;
                }
            }
        }

        for (int j=0; j<N; ++j) if (get_from_jigsaw(child, j)==-1) {
            for (int m=0; m<N; ++m) if (remain_list[m]!=0) {
                set_to_jigsaw(child, j, unique_codewords[m]);
                remain_list[m]--;
                break;
            }
        }

        float newcost = hill_climbing(child, adjacent_cost, location_cost);
        float mincost = INT_MAX;
        float maxcost = -INT_MAX+1;
        for (int j=0; j<P; ++j) {
            if (costs[j]<mincost){
                mincost = costs[j];
                minindex = j;
            }
            if (maxcost<costs[j]){
                maxcost = costs[j];
                maxindex = j;
            }
        }

        if (newcost < maxcost){
            if (rand_01(rng) < p){
                int min_dist = INT_MAX;
                for (int p1=0; p1<P; ++p1) for (int p2=p1+1; p2<P;++p2){
                    int dist = 0;
                    for (int j=0; j<N; ++j) if (get_from_jigsaw(population[p1],j)!=get_from_jigsaw(population[p2],j)) dist++;
                    if (dist<min_dist){
                        min_dist = dist;
                        maxindex = rand()%2==0 ? p1 : p2;
                    }
                }
            }
            costs[maxindex] = newcost;
            delete [] population[maxindex];
            population[maxindex] = child;
        }else{
            delete [] child;
        }

        if (i%1000 == 1) cout << "generation " << i << ": " << mincost << "," << maxcost << std::endl;
        if ((maxcost-mincost)<0.1) break;
        if (i>10000) break;
    }

    for (int i=0; i<N; i++ ) set_to_jigsaw(jigsaw, i, get_from_jigsaw(population[minindex], i));

    for (int i=0; i<P; ++i){
	delete [] population[i];
    }
    delete [] costs;
    delete [] num_codeword;
    delete [] unique_codewords;
    delete [] population;

    return compute_cost(jigsaw, adjacent_cost, location_cost);
}

