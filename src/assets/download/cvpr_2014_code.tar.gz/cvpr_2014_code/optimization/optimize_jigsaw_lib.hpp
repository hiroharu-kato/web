#ifndef OPTIMIZE_JIGSAW_LIB
#define OPTIMIZE_JIGSAW_LIB

// height and width of jigsaw
#define YMAX 13
#define XMAX 13

// total number of pieces
#define N (YMAX*XMAX)

typedef int* Jigsaw;            // int[N]
typedef float* AdjacentCost;    // float[N*N*7*7]
typedef float* LocationCost;    // float[N*N]

/* optimization method
 * NONE: only compute jigsaw score
 * HILL_CLIMBING: hill climbing
 * HILL_CLIMBING2: probabilistic hill climbing
 * SIMULATED_ANNEALING: simulated annealing
 * HYBRID_GENETIC_ALGORITHM: modified version of [Drezner et al., 2003] */
enum Method {NONE, HILL_CLIMBING, HILL_CLIMBING2, SIMULATED_ANNEALING, HYBRID_GENETIC_ALGORITHM};

/* jigsaw manipulation functions */
void swap(Jigsaw jigsaw, int pos1, int pos2);
void swap(Jigsaw jigsaw, int y1, int x1, int y2, int x2);
void shuffle(Jigsaw jigsaw);
void show_jigsaw(Jigsaw jigsaw);

/* main function to optimize a jigsaw
 * adjacent_cost_matrix: N*N*7*7 adjacent cost array
 * location_cost_matrix: N*N location cost array
 * method: optimization method */
float optimize(Jigsaw jigsaw, AdjacentCost adjacent_cost, LocationCost location_cost, Method method);

#endif
