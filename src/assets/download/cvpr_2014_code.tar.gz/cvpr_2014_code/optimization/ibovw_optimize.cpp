#include <iostream>
#include <sys/time.h>
#include "optimize_jigsaw_lib.hpp"
#include "mex.h"

using namespace std;

double sec(){
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

void mexFunction( int Nreturned, mxArray *returned[], int Noperand, const mxArray *operand[] ){
  Jigsaw jigsaw = new int[N];
  AdjacentCost adjacent_cost = new float[N*N*7*7];
  LocationCost location_cost = new float[N*N];

  if (Noperand != 4) return;
  if (Nreturned > 3) return;
  if (mxGetM(operand[0])!=YMAX) return;
  if (mxGetN(operand[0])!=XMAX) return;
  if (mxGetM(operand[1])!=N) return;
  if (mxGetN(operand[1])!=N*7*7) return;
  if (mxGetM(operand[2])!=N) return;
  if (mxGetN(operand[2])!=N) return;

  double* jigsaw2 = mxGetPr(operand[0]);
  for (int i=0; i<N; i++) jigsaw[i] = jigsaw2[i];
 
  double* adjacent_cost2 = mxGetPr(operand[1]);
  for (int i=0; i<N*N*7*7; i++) adjacent_cost[i] = adjacent_cost2[i];
  
  double* location_cost2 = mxGetPr(operand[2]);
  for (int i=0; i<N*N; i++) location_cost[i] = location_cost2[i];
  
  float cost;
  int method = mxGetPr(operand[3])[0];
  double sec1 = sec();
  switch (method) {
    case 0:
      cost = optimize(jigsaw, adjacent_cost, location_cost, NONE);
      break;
    case 1:
      cost = optimize(jigsaw, adjacent_cost, location_cost, HILL_CLIMBING);
      break;
    case 2:
      cost = optimize(jigsaw, adjacent_cost, location_cost, HILL_CLIMBING2);
      break;
    case 3:
      cost = optimize(jigsaw, adjacent_cost, location_cost, SIMULATED_ANNEALING);
      break;
    case 4:
      cost = optimize(jigsaw, adjacent_cost, location_cost, HYBRID_GENETIC_ALGORITHM);
      break;
  }
  double sec2 = sec();

  returned[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
  double* ret_cost = mxGetPr(returned[0]);
  *ret_cost = cost;
  
  returned[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
  double* ret_time = mxGetPr(returned[1]);
  *ret_time = sec2-sec1;

  returned[2] = mxCreateDoubleMatrix(YMAX, XMAX, mxREAL);
  double* ret_jigsaw = mxGetPr(returned[2]);
  for (int i=0; i<N; i++) ret_jigsaw[i] = jigsaw[i];

}
