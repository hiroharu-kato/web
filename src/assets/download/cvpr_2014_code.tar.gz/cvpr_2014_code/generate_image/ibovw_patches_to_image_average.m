function[img] = patches2image_average(patches)
	settings = ibovw_settings();

	img = zeros((settings.descriptor.ymax-1)*settings.descriptor.step+settings.descriptor.patchsize, (settings.descriptor.xmax-1)*settings.descriptor.step+settings.descriptor.patchsize, 3);
	
	count = zeros(size(img));
	for y=1:settings.descriptor.ymax; for x=1:settings.descriptor.xmax;
		patch = reshape(patches(y+(x-1)*settings.descriptor.ymax,:,:,:), settings.descriptor.patchsize, settings.descriptor.patchsize, 3);
		ypxmin = (y-1)*settings.descriptor.step+1;
		xpxmin = (x-1)*settings.descriptor.step+1;
		ypxmax = ypxmin+settings.descriptor.patchsize-1;
		xpxmax = xpxmin+settings.descriptor.patchsize-1;
		img(ypxmin:ypxmax, xpxmin:xpxmax, :) = img(ypxmin:ypxmax, xpxmin:xpxmax, :) + double(patch);
		count(ypxmin:ypxmax, xpxmin:xpxmax, :) = count(ypxmin:ypxmax, xpxmin:xpxmax, :) + 1;
	end; end;

	img(count~=0) = img(count~=0) ./ count(count~=0);
	img = uint8(img);
end
