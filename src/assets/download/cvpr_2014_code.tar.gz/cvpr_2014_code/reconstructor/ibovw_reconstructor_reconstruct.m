function [image, codenumbers, cost, time] = ibovw_reconstructor_reconstruct(reconstructor, codenumbers, is_11)
	settings = ibovw_settings();

	codenumbers = codenumbers(randperm(size(codenumbers, 2))); % shuffle

	% position cost normalization
	position_cost = reconstructor.position_cost(codenumbers,:);
	position_cost = position_cost + 1;
	position_cost(:,:) = position_cost(:,:) ./ repmat(sum(position_cost(:,:),2), 1, 169);
	position_cost = log(position_cost);
	
	% adjacent cost normalization
	t = sum(reconstructor.position_cost(codenumbers',:), 1);
	adjacent_cost = double(reconstructor.adjacent_cost(codenumbers, codenumbers', :,:));
	adjacent_cost = adjacent_cost + 1;
	for j=1:7; for l=1:7;
		adjacent_cost(:,:,j,l) = adjacent_cost(:,:,j,l) ./ (t*t');
		adjacent_cost(:,:,j,l) = adjacent_cost(:,:,j,l) ./ repmat(sum(adjacent_cost(:,:,j,l),2), 1, 169);
	end; end;
	for j=1:7; for l=1:7;
		area = (4-abs(4-j))*(4-abs(4-l));
		adjacent_cost(:,:,j,l) = adjacent_cost(:,:,j,l)*area/16;
	end; end;
	adjacent_cost = log(adjacent_cost);

	if nargin == 2 || is_11 == false
		% lambda = reconstructor.lambda
		jigsaw = 0:168;
		[cost, time, jigsaw] = ibovw_optimize(reshape(jigsaw, 13, 13), -adjacent_cost*reconstructor.lambda/(7*7-1), -position_cost*(1-reconstructor.lambda), reconstructor.optimization_method);
		codenumbers = codenumbers(reshape(jigsaw, 169, 1)+1);

		descriptors = reconstructor.visualwords(codenumbers,:);
		patches = ibovw_invertdescriptor_invert(descriptors);
		image = ibovw_patches_to_image_average(patches);
	else
		% lambda = 0:0.1:1
		codenumbers_ = codenumbers;
		codenumbers = {};
		cost = {};
		time = {};
		image = {};
		visualwords = reconstructor.visualwords;
		parfor i=0:10
			lambda = i/10;
			jigsaw = 0:168;
			[cost{i+1}, time{i+1}, jigsaw] = ibovw_optimize(reshape(jigsaw, 13, 13), -adjacent_cost*lambda/(7*7-1), -position_cost*(1-lambda), 4);
			codenumbers{i+1} = codenumbers_(reshape(jigsaw, 169, 1)+1);
			descriptors = visualwords(codenumbers{i+1},:);
			patches = ibovw_invertdescriptor_invert(descriptors);
			image{i+1} = ibovw_patches_to_image_average(patches);
		end
	end
end
