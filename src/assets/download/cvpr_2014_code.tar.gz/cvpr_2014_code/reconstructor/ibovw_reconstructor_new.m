function reconstructor = ibovw_reconstructor_new(k)
	settings = ibovw_settings();

	n = find(settings.visualword.nums == k);
	adjacent_cost = getfield(load(settings.adjacent_cost.filename{n}), 'adjacent_cost');
	position_cost = getfield(load(settings.position_cost.filename{n}), 'position_cost');
	visualwords = getfield(load(settings.visualword.filename{n}), 'visualwords');
	pca = load(settings.descriptor.filename_pca);

	reconstructor = struct();
	reconstructor.adjacent_cost = adjacent_cost;
	reconstructor.position_cost = position_cost;
	reconstructor.visualwords = visualwords;
	reconstructor.pca = pca;
	reconstructor.lambda = settings.reconstructor.lambda;
	reconstructor.optimization_method = settings.optimization_method;
end
