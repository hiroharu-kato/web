function scores = ibovw_experiment6()
	settings = ibovw_settings();

	directory_original = './external/dataset/original/';
	directory_experiment2 = './out/experiment2/';
	directory_experiment3 = './out/experiment3/';
	directory_experiment4 = './out/experiment4/';
	directory_experiment5 = './out/experiment5/';
	filename = dir([directory_original, '*.jpg']);

	scores = zeros(5, numel(settings.visualword.nums), numel(0:0.1:1), size(filename,1));

	for i = 1:numel(settings.visualword.nums)
		k = settings.visualword.nums(i);
		for j = 0:1:10
			disp(['k: ',num2str(k), ', lambda: ', num2str(j/10, '%.1f')]);
			s = zeros(5, size(filename,1));
			parfor l = 1:size(filename, 1)
				f = strsplit(filename(l).name, '.');
				fn = [strjoin(f(1:end-1), '.'), '_k', num2str(k), '_lambda', num2str(j/10, '%.1f')];
				
				img1 = imread([directory_original, strjoin(f(1:end), '.')]);
				img2 = imread([directory_experiment2, fn, '.', f{end}]);
				[xcorr, xcorr4, xcorr8] = ibovw_score_xcorr(img1, img2);

				m = load([directory_experiment2, fn, '.mat']);
				dc = ibovw_score_direct(m.codenumbers_correct, m.codenumbers_reconstructed);
				nc = ibovw_score_neighbor(m.codenumbers_correct, m.codenumbers_reconstructed);
				
				s(:, l) = [xcorr, xcorr4, xcorr8, dc, nc];
			end
			scores(:, i, j+1, :) = s;
		end
	end

	m = scores(1,end,:,:);
	xcorr_lambda = mean(reshape(m, size(m, 3), size(m,4)), 2)';
	m = scores(2,end,:,:);
	xcorr4_lambda = mean(reshape(m, size(m, 3), size(m,4)), 2)';
	m = scores(3,end,:,:);
	xcorr8_lambda = mean(reshape(m, size(m, 3), size(m,4)), 2)';
	m = scores(4,end,:,:);
	dc_lambda = mean(reshape(m, size(m, 3), size(m,4)), 2)';
	m = scores(5,end,:,:);
	nc_lambda = mean(reshape(m, size(m, 3), size(m,4)), 2)';

	m = scores(1,:,end,:);
	xcorr_k = mean(reshape(m, size(m, 2), size(m,4)), 2)';
	m = scores(2,:,end,:);
	xcorr4_k = mean(reshape(m, size(m, 2), size(m,4)), 2)';
	m = scores(3,:,end,:);
	xcorr8_k = mean(reshape(m, size(m, 2), size(m,4)), 2)';
	m = scores(4,:,end,:);
	dc_k = mean(reshape(m, size(m, 2), size(m,4)), 2)';
	m = scores(5,:,end,:);
	nc_k = mean(reshape(m, size(m, 2), size(m,4)), 2)';

	lambda = (find(xcorr8_lambda==max(xcorr8_lambda))-1)/10;
	[~, m] = sort(scores(5,end,lambda*10+1,:));
	m = m(:)';
	best = m(end:-1:end-10+1);
	worst = m(1:10);

	xcorr_ir = 0;
	xcorr4_ir = 0;
	xcorr8_ir = 0;
	xcorr_hoggles = 0;
	xcorr4_hoggles = 0;
	xcorr8_hoggles = 0;
	for i = 1:size(filename, 1)
		img1 = imread([directory_original, filename(i).name]);

		img2 = imread([directory_experiment3, filename(i).name]);
		[xcorr, xcorr4, xcorr8] = ibovw_score_xcorr(img1, img2);
		xcorr_ir = xcorr_ir + xcorr;
		xcorr4_ir = xcorr4_ir + xcorr4;
		xcorr8_ir = xcorr8_ir + xcorr8;

		img2 = imread([directory_experiment4, filename(i).name]);
		[xcorr, xcorr4, xcorr8] = ibovw_score_xcorr(img1, img2);
		xcorr_hoggles = xcorr_hoggles + xcorr;
		xcorr4_hoggles = xcorr4_hoggles + xcorr4;
		xcorr8_hoggles = xcorr8_hoggles + xcorr8;
	end
	xcorr_ir = xcorr_ir / size(filename,1);
	xcorr4_ir = xcorr4_ir / size(filename,1);
	xcorr8_ir = xcorr8_ir / size(filename,1);
	xcorr_hoggles = xcorr_hoggles / size(filename,1);
	xcorr4_hoggles = xcorr4_hoggles / size(filename,1);
	xcorr8_hoggles = xcorr8_hoggles / size(filename,1);

	% optimization
	scores_o = zeros(7, numel(0:4), size(filename,1));
	for j = 0:4
		s = zeros(7, size(filename,1));
		parfor l = 1:size(filename, 1)
			f = strsplit(filename(l).name, '.');
			fn = [strjoin(f(1:end-1), '.'), '_m', num2str(j)];
			
			img1 = imread([directory_original, strjoin(f(1:end), '.')]);
			img2 = imread([directory_experiment5, fn, '.', f{end}]);
			[xcorr, xcorr4, xcorr8] = ibovw_score_xcorr(img1, img2);

			m = load([directory_experiment5, fn, '.mat']);
			dc = ibovw_score_direct(m.codenumbers_correct, m.codenumbers_reconstructed);
			nc = ibovw_score_neighbor(m.codenumbers_correct, m.codenumbers_reconstructed);
			cost = m.cost;
			time = m.time;
			
			s(:, l) = [xcorr, xcorr4, xcorr8, dc, nc, cost, time];
		end
		scores_o(:, j+1, :) = s;
	end

	disp(sprintf('\n'));
	disp(sprintf('\n'));

	% best and worst
	disp(sprintf(['best results:\t', num2str(best)]));
	disp(sprintf(['worst results:\t', num2str(worst)]));
	disp(sprintf('\n'));

	% method
	disp('method and score');
	disp(sprintf('method \t XCORR \t XCORR4 \t XCORR8'));
	disp(sprintf(['Proposed \t', num2str(mean(scores(1:3,end,end-2,:), 4)', '%10.4f')]));
	disp(sprintf(['Hoggles \t', num2str([xcorr_hoggles, xcorr4_hoggles, xcorr8_hoggles], '%10.4f')]));
	disp(sprintf(['IR \t', num2str([xcorr_ir, xcorr4_ir, xcorr8_ir], '%10.4f')]));
	disp(sprintf('\n'));

	% lambda and score
	disp('lambda and score');
	disp(sprintf(['lambda \t', num2str(0:0.1:1, '%10.4f')]));
	disp(sprintf(['XCORR \t', num2str(xcorr_lambda, '%10.4f')]));
	disp(sprintf(['XCORR4 \t', num2str(xcorr4_lambda, '%10.4f')]));
	disp(sprintf(['XCORR8 \t', num2str(xcorr8_lambda, '%10.4f')]));
	disp(sprintf(['DC \t', num2str(dc_lambda, '%10.4f')]));
	disp(sprintf(['NC \t', num2str(nc_lambda, '%10.4f')]));
	disp(sprintf('\n'));

	% k and score
	disp('k and score');
	disp(sprintf(['k \t', num2str(settings.visualword.nums, '%10.0f')]));
	disp(sprintf(['XCORR \t', num2str(xcorr_k, '%10.4f')]));
	disp(sprintf(['XCORR4 \t', num2str(xcorr4_k, '%10.4f')]));
	disp(sprintf(['XCORR8 \t', num2str(xcorr8_k, '%10.4f')]));
	disp(sprintf(['DC \t', num2str(dc_k, '%10.4f')]));
	disp(sprintf(['NC \t', num2str(nc_k, '%10.4f')]));
	disp(sprintf('\n'));

	% optimization
	disp('optimization');
	disp(sprintf('method \t XCORR \t XCORR4 \t XCORR8 \t DC \t NC \t cost \t time'));
	disp(sprintf(['RAND\t', num2str(mean(scores_o(:,1,:),3)', '%10.4f')]));
	disp(sprintf(['HC\t', num2str(mean(scores_o(:,2,:),3)', '%10.4f')]));
	disp(sprintf(['SHC\t', num2str(mean(scores_o(:,3,:),3)', '%10.4f')]));
	disp(sprintf(['SA\t', num2str(mean(scores_o(:,4,:),3)', '%10.4f')]));
	disp(sprintf(['GA+HC\t', num2str(mean(scores_o(:,5,:),3)', '%10.4f')]));
	disp(sprintf('\n'));
end
