function ibovw_experiment2()
	settings = ibovw_settings();

	directory_original = './external/dataset/original/';
	directory_output = './out/experiment2/';
	mkdir(directory_output);
	filename = dir([directory_original, '*.jpg']);
	pca = load(settings.descriptor.filename_pca);
	for j=1:size(settings.visualword.nums, 2)
		k = settings.visualword.nums(j);
		reconstructor = ibovw_reconstructor_new(k);

		matlabpool;
		for i=1:size(filename, 1)
			if mod(i, 10) == 0
				matlabpool close;
				matlabpool;
			end
			img = imread([directory_original, filename(i).name]);
			[~, codenumbers] = ibovw_extract_bovw(img, k);
			[img, codenumbers2, costs, times] = ibovw_reconstructor_reconstruct(reconstructor, codenumbers, true);

			for l=0:10
				f = strsplit(filename(i).name, '.');
				fn = [strjoin(f(1:end-1), '.'), '_k', num2str(k), '_lambda', num2str(l/10, '%.1f')];
				imwrite(img{l+1}, [directory_output, fn, '.', f{end}]);

				codenumbers_correct = codenumbers;
				codenumbers_reconstructed = codenumbers2{l+1};
				cost = costs{l+1};
				time = times{l+1};
				save([directory_output, fn, '.mat'], 'codenumbers_correct', 'codenumbers_reconstructed', 'cost', 'time');
			end
		end
		matlabpool close;
	end
end
