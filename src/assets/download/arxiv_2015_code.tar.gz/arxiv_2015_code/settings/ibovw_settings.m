function settings = ibovw_settings()
	descriptor = 'SIFT';

	settings = struct();
	settings.mat_directory = ['./mat/', descriptor, '/'];;


	%%%%% image %%%%%
 	settings.image.width = 128;
 	settings.image.height = 128;
 	settings.image.size = [settings.image.height, settings.image.width];


	%%%%% dataset %%%%%
	settings.dataset.directory_original = './external/dataset/ILSVRC2012/';
	settings.dataset.filename = '*.JPEG';
	settings.dataset.nums = [10000, 100000, 1000000];
	settings.dataset.directory = [settings.dataset.directory_original, int2str(settings.image.size(1)), 'x' int2str(settings.image.size(2)), '/'];
	for i=1:size(settings.dataset.nums, 2)
		settings.dataset.filename_imagelist{i} = [settings.dataset.directory, 'imagelist_', int2str(settings.dataset.nums(i))];	
	end


	%%%%% descriptor %%%%%
	settings.descriptor.kind = descriptor;
	if strcmp(descriptor, 'SIFT')
		settings.descriptor.color = false;
		settings.descriptor.dim = 128;
	elseif strcmp(descriptor, 'HOG')
		settings.descriptor.color = false;
		settings.descriptor.dim = 128;
	elseif strcmp(descriptor, 'LBP')
		settings.descriptor.color = false;
		settings.descriptor.dim = 58;
	elseif strcmp(descriptor, 'OSIFT')
		settings.descriptor.color = true;
		settings.descriptor.dim = 128*3;
	elseif strcmp(descriptor, 'RGBSIFT')
		settings.descriptor.color = true;
		settings.descriptor.dim = 128*3;
 	end
	settings.descriptor.step = 8;
 	settings.descriptor.patchsize = 32;
 	settings.descriptor.ymax = (settings.image.height-settings.descriptor.patchsize)/settings.descriptor.step+1;
 	settings.descriptor.xmax = (settings.image.width-settings.descriptor.patchsize)/settings.descriptor.step+1;
 	settings.descriptor.num = settings.descriptor.ymax*settings.descriptor.xmax;
	settings.descriptor.filename_pca = [settings.mat_directory, 'pca'];
	settings.descriptor.pca_contribution_ratio = 0.95;


	%%%%% visualword %%%%%
	settings.visualword.dim = '095';
	settings.visualword.nums = [2^7, 2^8, 2^9, 2^10, 2^11, 2^12, 2^13];
	for i=1:size(settings.visualword.nums, 2)
		settings.visualword.filename{i} = [settings.mat_directory, 'visualword_', int2str(settings.visualword.nums(i))];	
	end

	
	%%%%% descriptor_database
	settings.descriptor_database.imagelist = settings.dataset.filename_imagelist{1};	
	settings.descriptor_database.filename = [settings.mat_directory, 'descriptor_database'];


	%%%%% quantized_descriptor_database %%%%%
	settings.quantized_descriptor_database.imagelist = settings.dataset.filename_imagelist{end};	
	for i=1:size(settings.visualword.nums, 2)
		settings.quantized_descriptor_database.filename{i} = [settings.mat_directory, 'quantized_descriptor_database_', int2str(settings.visualword.nums(i))];	
	end


	%%%%% bovw_database %%%%%
	for i=1:size(settings.visualword.nums, 2)
		settings.bovw_database.filename{i} = [settings.mat_directory, 'bovw_database_', int2str(settings.visualword.nums(i))];	
	end


	%%%%% cost %%%%%
	for i=1:size(settings.visualword.nums, 2)
		settings.position_cost.filename{i} = [settings.mat_directory, 'position_cost_', int2str(settings.visualword.nums(i))];	
		settings.adjacent_cost.filename{i} = [settings.mat_directory, 'adjacent_cost_', int2str(settings.visualword.nums(i))];	
	end


	%%%%% invertdescriptor %%%%%
	settings.invertdescriptor.imagelist = settings.dataset.filename_imagelist{1};	
	settings.invertdescriptor.filename_Z = [settings.mat_directory, 'invertdescriptor_Z'];
	settings.invertdescriptor.filename_UV = [settings.mat_directory, 'invertdescriptor_UV'];
	settings.invertdescriptor.param.iter=10;
	settings.invertdescriptor.param.K=1000;
	settings.invertdescriptor.param.posAlpha=true;
	settings.invertdescriptor.param.numThreads=-1;
	settings.invertdescriptor.param.verbose = 1;
	settings.invertdescriptor.param.mode = 2;
	settings.invertdescriptor.param.modeD = 0;
	settings.invertdescriptor.param.batchsize = 400;
	settings.invertdescriptor.param.lambda = 0.005;


	%%%%% reconstructor %%%%%
	settings.reconstructor.lambda = 0.8;
	settings.optimization_method = 4;
end
