function ibovw_make_descriptor_database()
	% make descriptor database
	% descriptor_database(IMAGE_INDEX, POSITION_INDEX, :) = LOCAL_DESCRIPTOR

	settings = ibovw_settings();

	imagelist = getfield(load(settings.descriptor_database.imagelist), 'imagelist');

	descriptor_database = zeros(size(imagelist, 2), settings.descriptor.num, settings.descriptor.dim);

	parfor i=1:size(imagelist, 2)
		disp(i);
		image = imread([settings.dataset.directory, imagelist{i}]);

		descriptors = ibovw_extract_descriptors(image);
		descriptor_database(i,:,:) = descriptors;
	end

	save(settings.descriptor_database.filename, 'descriptor_database', '-v7.3');
end
