function [descriptors, y, x] = rc_extract_descriptors(image, kind)
	settings = ibovw_settings();

	if nargin == 1
		kind = settings.descriptor.kind;
	end

	if strcmp(kind, 'SIFT')
		SIFTparam.grid_spacing = settings.descriptor.step;
		SIFTparam.patch_size = settings.descriptor.patchsize;
		[SIFT, ~] = LMdenseSift(image, '', SIFTparam);
	
		descriptors = reshape(SIFT, settings.descriptor.num, []);
	elseif strcmp(kind, 'OSIFT')
		if ndims(image) ~= 3
			image = repmat(image, [1,1,3]);
		end
		image = im2single(image);
		o1 = (image(:,:,1) - image(:,:,2) + eps) ./ sqrt(2);	
		o2 = (image(:,:,1) + image(:,:,2) - 2*image(:,:,3) + eps) ./ sqrt(6);	
		o3 = (image(:,:,1) + image(:,:,2) + image(:,:,3)) ./ sqrt(3);
		s1 = ibovw_extract_descriptors(o1, 'SIFT');
		s2 = ibovw_extract_descriptors(o2, 'SIFT');
		s3 = ibovw_extract_descriptors(o3, 'SIFT');
		descriptors = [s1,s2,s3];
	elseif strcmp(kind, 'RGBSIFT')
		if ndims(image) ~= 3
			image = repmat(image, [1,1,3]);
		end
		image = im2single(image);
		s1 = ibovw_extract_descriptors(image(:,:,1), 'SIFT');
		s2 = ibovw_extract_descriptors(image(:,:,2), 'SIFT');
		s3 = ibovw_extract_descriptors(image(:,:,3), 'SIFT');
		descriptors = [s1,s2,s3];
	elseif strcmp(kind, 'HOG')
		if ndims(image) == 3
			image = rgb2gray(image);
		end
		image = im2single(image);
		descriptors = [];
		for x=1:settings.descriptor.xmax; for y=1:settings.descriptor.ymax;
			subimage = image((y-1)*settings.descriptor.step+1:(y-1)*settings.descriptor.step+settings.descriptor.patchsize,(x-1)*settings.descriptor.step+1:(x-1)*settings.descriptor.step+settings.descriptor.patchsize);
			descriptors = [descriptors; reshape(hog_ihog(repmat(double(subimage), [1,1,3]), 8), 1, [])];
		end; end;
	elseif strcmp(kind, 'LBP')
		if ndims(image) == 3
			image = rgb2gray(image);
		end
		image = im2single(image);
		descriptors = [];
		for x=1:settings.descriptor.xmax; for y=1:settings.descriptor.ymax;
			subimage = image((y-1)*settings.descriptor.step+1:(y-1)*settings.descriptor.step+settings.descriptor.patchsize,(x-1)*settings.descriptor.step+1:(x-1)*settings.descriptor.step+settings.descriptor.patchsize);
			descriptors = [descriptors; reshape(vl_lbp(subimage, 32), 1, [])];
		end; end;
	else
 		throw(MException('', 'Not implemented'));
	end
end
