function [codenumbers, descriptors] = ibovw_quantize_descriptors(descriptors, visualwords)
	codenumbers = knnsearch(single(visualwords), single(descriptors));
	if nargout == 2
		descriptors = visualwords(codenumbers, :);
	end
end
