function [] = rc_make_visualwords()
	% make visual word dictionary by k-means clustering from descriptor_database

	settings = ibovw_settings();

	descriptor_database = getfield(load(settings.descriptor_database.filename), 'descriptor_database');
	descriptor_database = reshape(descriptor_database, [], settings.descriptor.dim);
	pca = load(settings.descriptor.filename_pca);
	descriptor_database = descriptor_database*pca.coeff;
	descriptor_database = descriptor_database(:, 1:pca.dim);

	for i=1:size(settings.visualword.nums, 2)
		num = settings.visualword.nums(i);
	
		c = yael_kmeans(single(descriptor_database)', num, 'init', 1, 'redo', 1);
		visualwords = c';

		save(settings.visualword.filename{i}, 'visualwords', '-v7.3');
	end
end
