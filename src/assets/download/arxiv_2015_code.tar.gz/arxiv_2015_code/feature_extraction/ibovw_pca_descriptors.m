function ibovw_pca_descriptors()
	% compute coefficients for compressing descriptors
	% coeffs are obtained from descriptor_database

	settings = ibovw_settings();

	descriptors = getfield(load(settings.descriptor_database.filename), 'descriptor_database');
	descriptors = reshape(descriptors, [], settings.descriptor.dim);

	[coeff, ~, latent, ~] = princomp(descriptors);
	dim = find(settings.descriptor.pca_contribution_ratio<cumsum(latent)./sum(latent), 1);

	save(settings.descriptor.filename_pca, 'coeff', 'latent', 'dim');
end
