function ibovw_make_adjacent_cost()
	settings = ibovw_settings();

	for i=1:size(settings.visualword.nums,2)
		k = settings.visualword.nums(i);

		quantized = getfield(load(settings.quantized_descriptor_database.filename{i}), 'descriptor_database');	
		adjacent_cost = int32(zeros(k, k, 7, 7));

		for right=-3:3;
			t_adjacent_cost = int32(zeros(k, k, 7));
			parfor down=-3:3; 
				[down, right]
				s1 = (13-abs(down))*(13-abs(right));
				s2 = size(quantized, 1);
				m = zeros(s1*s2, 2);
				mm = reshape(quantized', 13, 13, s2);
				m1 = mm(max(1-down,1):min(13-down,13),max(1-right,1):min(13-right,13),:);
				m2 = mm(max(1+down,1):min(13+down,13),max(1+right,1):min(13+right,13),:);
				m1 = reshape(m1, numel(m1), 1);
				m2 = reshape(m2, numel(m2), 1);
				
				h = hist2(m1, m2, 1:k, 1:k);
				t_adjacent_cost(:,:,down+4) = int32(h);
			end;
			adjacent_cost(:,:,:,right+4) = t_adjacent_cost;
 		end;
		
		save(settings.adjacent_cost.filename{i}, 'adjacent_cost', '-v7.3');
	end
end
