function ibovw_make_position_cost()
	settings = ibovw_settings();

	for i=1:size(settings.visualword.nums, 2)
		k = settings.visualword.nums(i);
		
		position_cost = double(zeros(settings.descriptor.num, k));
		dd = getfield(load(settings.quantized_descriptor_database.filename{i}), 'descriptor_database'); 
		parfor j=1:settings.descriptor.num
			position_cost(j,:) = histc(dd(:,j), 1:k);
		end
		position_cost = position_cost';
		save(settings.position_cost.filename{i}, 'position_cost');
	end	
end
