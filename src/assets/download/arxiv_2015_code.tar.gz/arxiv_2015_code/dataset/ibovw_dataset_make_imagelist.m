function ibovw_make_imagelist()
	% make imagefile list
	% that contains settings.dataset.nums(i) images

	settings = ibovw_settings();
	
	list = dir([settings.dataset.directory, settings.dataset.filename]);
	rp = randperm(size(list, 1));

	for i=1:size(settings.dataset.nums, 2)
		num = settings.dataset.nums(i);
		imagelist = {};
		parfor j=1:num
			imagelist{j} = list(rp(j)).name;
		end
		save(settings.dataset.filename_imagelist{i}, 'imagelist', '-v7.3');	
	end
end	
