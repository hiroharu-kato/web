function ibovw_dataset_resize()
	% make resized dataset
	% [settings.dataset.directory_original, settings.dataset.filename] 
	% 	-> [settings.dataset.directory, settings.dataset.filename] 

	settings = ibovw_settings();

	if ~exist(settings.dataset.directory)
		mkdir(settings.dataset.directory);
	end

	list = dir([settings.dataset.directory_original, settings.dataset.filename]);

	parfor i=1:size(list,1)
		disp(['resize: ', num2str(i), '/', num2str(size(list,1))]);
		img = imresize(imread([settings.dataset.directory_original, list(i).name]), settings.image.size);
		imwrite(img, [settings.dataset.directory, list(i).name]);	
	end
end
