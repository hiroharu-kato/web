#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <queue>

#include <boost/numeric/ublas/io.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/random.hpp>
#include <boost/timer.hpp>

enum Method{ HILL_CLIMBING=0, SIMULATED_ANNEALING=1 };

float compute_swap_score(int** jigsaw, float** score_matrix, int ymax, int xmax, int k, int y1, int x1, int y2, int x2);
float compute_score(int** jigsaw, float** score_matrix, int ymax, int xmax, int k);
void swap(int** jigsaw, int ymax, int xmax, int y1, int x1, int y2, int x2);

float hill_climbing(int** jigsaw, float** score_matrix, int ymax, int xmax, int k);
float hill_climbing2(int** jigsaw, float** score_matrix, int ymax, int xmax, int k);
float simulated_annealing(int** jigsaw, float** score_matrix, int ymax, int xmax, int k);

float** create_float_matrix(int y, int x);
int** create_int_matrix(int y, int x);

int y_x_to_index(int y, int x, int ymax);
void index_to_y_x(int index, int ymax, int* y, int* x);

int main(void)
{
    typedef boost::mt19937 RandEngine;
    typedef boost::uniform_01<float> RandRange;
    typedef boost::variate_generator<RandEngine&, RandRange> RandGenerator;
    const int ymax = 13;
    const int xmax = 13;
    int n = ymax*xmax;
    int k = 1000;

    float** score_matrix = create_float_matrix(k*k,7*7);
    int** jigsaw = create_int_matrix(ymax, xmax);

    boost::timer t;
    for(int i=0; i<k*k; i++) for(int j=0; j<7*7; j++){
        score_matrix[i][j] = rand()/(float)RAND_MAX;
    }
    for(int y=0; y<ymax; y++) for(int x=0; x<xmax; x++){
        jigsaw[y][x] = rand() % k;
    }
   
    int score1; 
    // std::cout << score_matrix << std::endl;
    //float score1 = compute_score(&jigsaw, &score_matrix);
    //float cc = compute_swap_score(&jigsaw, &score_matrix, 5, 5, 6, 6);
    //swap(&jigsaw, 5, 5, 6, 6);
    //float score2 = compute_score(&jigsaw, &score_matrix);
    //std::cout << "swap_score: " << cc << std::endl;
    //std::cout << "score2-score1: " << score2-score1 << std::endl;
    
    t.restart();
    //score1 = compute_score(&jigsaw, &score_matrix);
    //std::cout << score1 << std::endl;
    //for (int i=0;i<100;i++) score1 = hill_climbing2(&jigsaw, &score_matrix);
    //std::cout << score1 << std::endl;
    score1 = hill_climbing2(jigsaw, score_matrix, ymax, xmax, k);
    std::cout << score1 << std::endl;
    //score1 = simulated_annealing(&jigsaw, &score_matrix);
    //std::cout << score1 << std::endl;
    std::cout << t.elapsed() << std::endl;
    return EXIT_SUCCESS;
}

float** create_float_matrix(int y, int x){
    float** array = new float*[y];
    for (int i=0; i<y; i++){
        array[i] = new float[x];
    }
    return array;
}

int** create_int_matrix(int y, int x){
    int** array = new int*[y];
    for (int i=0; i<y; i++){
        array[i] = new int[x];
    }
    return array;
}

/* optimization fuctions */
float hill_climbing(int** jigsaw, float** score_matrix, int ymax, int xmax, int k){
    float score;
    float diff, max_diff;
    int y1, x1, y2, x2, max_diff_x1, max_diff_y1, max_diff_x2, max_diff_y2;
    int pos1, pos2, count;
    std::queue<float> scores;
    
    count = 0;
    while (true) {
        max_diff = 0;
        for (pos1=0; pos1<ymax*xmax; pos1++) 
            for (pos2=pos1+1; pos2<ymax*xmax; pos2++){
                index_to_y_x(pos1, ymax, &y1, &x1);
                index_to_y_x(pos2, ymax, &y2, &x2);
                
                diff = compute_swap_score(jigsaw, score_matrix, ymax, xmax, k, y1, x1, y2, x2);
                if (max_diff < diff){
                    max_diff = diff;
                    max_diff_y1 = y1;
                    max_diff_x1 = x1;
                    max_diff_y2 = y2;
                    max_diff_x2 = x2;
                }
            }
        swap(jigsaw, ymax, xmax, max_diff_y1, max_diff_x1, max_diff_y2, max_diff_x2);
        count += 1;
        score = compute_score(jigsaw, score_matrix, ymax, xmax, k);
        scores.push(score);
        if (count > ymax*xmax){
            if (abs(score-scores.front())<0.01) break;
            scores.pop();
        }
    }
    return score;
}


float hill_climbing2(int** jigsaw, float** score_matrix, int ymax, int xmax, int k){
    int y1, x1, y2, x2;
    float score, diff;
    
    for (int i=0;i<5*pow(ymax*xmax, 2);i++){
        y1 = rand() % ymax;
        x1 = rand() % xmax;
        y2 = rand() % ymax;
        x2 = rand() % xmax;
        diff = compute_swap_score(jigsaw, score_matrix, ymax, xmax, k, y1, x1, y2, x2);
        if (diff>0) {
            swap(jigsaw, ymax, xmax, y1, x1, y2, x2);
        }
    }
    score = compute_score(jigsaw, score_matrix, ymax, xmax, k);
    return score;
}


float simulated_annealing(int** jigsaw, float** score_matrix, int ymax, int xmax, int k){
    float score;
    int y1, x1, y2, x2;
    std::queue<float> scores;

    float t = 1;
    float annealing_k = 1000;
    float alpha = 0.99;

    score = compute_score(jigsaw, score_matrix, ymax, xmax, k);
    for (int i=0; i<ymax*xmax*100; i++){
        float score_old = score;
        for (int j=0; j<1000; j++) {
            y1 = rand() % ymax;
            x1 = rand() % xmax;
            y2 = rand() % ymax;
            x2 = rand() % xmax;
            float diff = compute_swap_score(jigsaw, score_matrix, ymax, xmax, k, y1, x1, y2, x2);
            if ((diff>0)||(exp(diff/(annealing_k*t))>rand()/RAND_MAX)) {
                swap(jigsaw, ymax, xmax, y1, x1, y2, x2);
                score += diff;
            }
        }
        
        score = compute_score(jigsaw, score_matrix, ymax, xmax, k);
        if ((score-score_old)<0) t *= alpha;
        if (i%1000==0) {
            scores.push(score);
            if (i > scores.size()>3){
                if (abs(score-scores.front())<0.01) break;
                scores.pop();
            }
        }
    }
    return score;
}


/* index translation functions */
int yshift_xshift_to_index(int yshift, int xshift){
    yshift += 3;
    xshift += 3;
    return yshift + xshift*7;
}


int y_x_to_index(int y, int x, int ymax){
    return y+x*ymax;
}

void index_to_y_x(int index, int ymax, int* y, int* x){
    *y = index % ymax;
    *x = index / ymax;
}

int num1_num2_to_index(int num1, int num2, int num_max){
    return num1 + num2*num_max;
}

/* jigsaw manupilation functions */
void swap(int** jigsaw, int ymax, int xmax, int y1, int x1, int y2, int x2){
    int num1 = jigsaw[y1][x1];
    int num2 = jigsaw[y2][x2];
    jigsaw[y1][x1] = num2;
    jigsaw[y2][x2] = num1;
}


/* score computation functions */
float compute_score(int** jigsaw, float** score_matrix, int ymax, int xmax, int k){
    float score = 0;
    int num1, num2, shiftindex;

    for (int y1=0; y1<ymax; y1++) for (int x1=0; x1<xmax; x1++){
        num1 = jigsaw[y1][x1];
        for (int y2=std::max(y1-3,0); y2<std::min(y1+3+1,ymax); y2++)
            for (int x2=std::max(x1-3,0); x2<std::min(x1+3+1,xmax); x2++) {
                num2 = jigsaw[y2][x2];
                shiftindex = yshift_xshift_to_index(y2-y1, x2-x1);
                score += score_matrix[num1_num2_to_index(num1,num2,k)][shiftindex];
            }
    }
    return score;
}


float compute_swap_score(int** jigsaw, float** score_matrix, int ymax, int xmax, int k, int y1, int x1, int y2, int x2){
    float swap_score = 0;
    int shiftindex;
    int num1, num2;
    
    num1 = jigsaw[y1][x1];
    for (int y=std::max(y1-3,0); y<std::min(y1+3+1,ymax); y++)
        for (int x=std::max(x1-3,0); x<std::min(x1+3+1,xmax); x++) {
            num2 = jigsaw[y][x];
            shiftindex = yshift_xshift_to_index(y-y1, x-x1);
            swap_score -= score_matrix[num1_num2_to_index(num1,num2,k)][shiftindex];
            shiftindex = yshift_xshift_to_index(y1-y, x1-x);
            swap_score -= score_matrix[num1_num2_to_index(num2,num1,k)][shiftindex];
        }

    num1 = jigsaw[y2][x2];
    for (int y=std::max(y2-3,0); y<std::min(y2+3+1,ymax); y++)
        for (int x=std::max(x2-3,0); x<std::min(x2+3+1,xmax); x++) {
            num2 = jigsaw[y][x];
            shiftindex = yshift_xshift_to_index(y-y2, x-x2);
            swap_score -= score_matrix[num1_num2_to_index(num1,num2,k)][shiftindex];
            shiftindex = yshift_xshift_to_index(y2-y, x2-x);
            swap_score -= score_matrix[num1_num2_to_index(num2,num1,k)][shiftindex];
        }

    if ((abs(y2-y1)<4)&&(abs(x2-x1)<4)){
        num1 = jigsaw[y1][x1];
        num2 = jigsaw[y2][x2];
        shiftindex = yshift_xshift_to_index(y2-y1, x2-x1);
        swap_score += score_matrix[num1_num2_to_index(num1,num2,k)][shiftindex];
        shiftindex = yshift_xshift_to_index(y1-y2, x1-x2);
        swap_score += score_matrix[num1_num2_to_index(num2,num1,k)][shiftindex];
    }

    swap(jigsaw, ymax, xmax, y1, x1, y2, x2);

    num1 = jigsaw[y1][x1];
    for (int y=std::max(y1-3,0); y<std::min(y1+3+1,ymax); y++)
        for (int x=std::max(x1-3,0); x<std::min(x1+3+1,xmax); x++) {
            num2 = jigsaw[y][x];
            shiftindex = yshift_xshift_to_index(y-y1, x-x1);
            swap_score += score_matrix[num1_num2_to_index(num1,num2,k)][shiftindex];
            shiftindex = yshift_xshift_to_index(y1-y, x1-x);
            swap_score += score_matrix[num1_num2_to_index(num2,num1,k)][shiftindex];
        }


    num1 = jigsaw[y2][x2];
    for (int y=std::max(y2-3,0); y<std::min(y2+3+1,ymax); y++)
        for (int x=std::max(x2-3,0); x<std::min(x2+3+1,xmax); x++) {
            num2 = jigsaw[y][x];
            shiftindex = yshift_xshift_to_index(y-y2, x-x2);
            swap_score += score_matrix[num1_num2_to_index(num1,num2,k)][shiftindex];
            shiftindex = yshift_xshift_to_index(y2-y, x2-x);
            swap_score += score_matrix[num1_num2_to_index(num2,num1,k)][shiftindex];
        }

    if ((abs(y2-y1)<4)&&(abs(x2-x1)<4)){
        num1 = jigsaw[y1][x1];
        num2 = jigsaw[y2][x2];
        shiftindex = yshift_xshift_to_index(y2-y1, x2-x1);
        swap_score -= score_matrix[num1_num2_to_index(num1,num2,k)][shiftindex];
        shiftindex = yshift_xshift_to_index(y1-y2, x1-x2);
        swap_score -= score_matrix[num1_num2_to_index(num2,num1,k)][shiftindex];
    }
    
    swap(jigsaw, ymax, xmax, y1, x1, y2, x2);
    
    return swap_score;
}
