#include <cmath>
#include <iostream>
#include "optimize_jigsaw_lib.hpp"

using namespace std;

void test();

int main(void) {
    test();
    return 0;
}

void test(){
    srand(time(NULL));
    int jigsaw[N];
    float adjacent_cost[N*N*7*7];
    float location_cost[N*N];

    // create jigsaw
    for (int i=0; i<N; i++) jigsaw[i] = i;

    // create cost
    for (int i=0; i<N*N*7*7; ++i) adjacent_cost[i] = 0;
    for (int i=0; i<N*N;     ++i) location_cost[i] = 0;

    // test cost
    for (int i=0; i<N; i++) {
        int y = i % YMAX;
        int x = i / YMAX;
        if (x != 0) adjacent_cost[(i-YMAX)+i*N+N*N*(3+4*7)] = -1;
        if (y != 0) adjacent_cost[(i-1)+i*N+N*N*(4+3*7)] = -1;
    }
    for (int i=0; i<N; ++i) location_cost[i+i*N] = -0.1;

    shuffle(jigsaw);
    cout << "none: " << optimize(jigsaw, adjacent_cost, location_cost, NONE) << endl;

    shuffle(jigsaw);
    cout << "hill_climbing: " << optimize(jigsaw, adjacent_cost, location_cost, HILL_CLIMBING) << endl;

    shuffle(jigsaw);
    cout << "hill_climbing2: " << optimize(jigsaw, adjacent_cost, location_cost, HILL_CLIMBING2) << endl;

    shuffle(jigsaw);
    cout << "simulated_annealing: " << optimize(jigsaw, adjacent_cost, location_cost, SIMULATED_ANNEALING) << endl;

    shuffle(jigsaw);
    cout << "hybrid_genetic_algorithm: " << optimize(jigsaw, adjacent_cost, location_cost, HYBRID_GENETIC_ALGORITHM) << endl;
    show_jigsaw(jigsaw);
}
