function ibovw_experiment7()
	num_start = 16;
	num_end = 40;
	k = 8192;

	directory_original = './external/dataset/original/';
	directory_output = './out/experiment7/';

	settings = ibovw_settings();
	mkdir(directory_output);
	mkdir('./out/experiment13/');

	bovw_s = ibovw_extract_bovw(imread([directory_original, num2str(num_start, '%03d'), '.jpg']), k);
	bovw_e = ibovw_extract_bovw(imread([directory_original, num2str(num_end, '%03d'), '.jpg']), k);
	bovws = bovw_s;
	while true
		bovws = [bovws;bovws(end,:)];

		diff = bovw_e - bovws(end,:);	
		diff(diff<0) = 0;
		indices = find(diff);
		index = indices(randi(size(indices,2)));
		bovws(end,index) = bovws(end,index) + 1;

		diff = bovws(end,:) - bovw_e;	
		diff(diff<0) = 0;
		indices = find(diff);
		index = indices(randi(size(indices,2)));
		bovws(end,index) = bovws(end,index) - 1;

		if norm(bovws(end,:) - bovw_e) == 0
			break
		end
	end

	reconstructor = ibovw_reconstructor_new(k);
	directory = [directory_output, num2str(num_start), '_', num2str(num_end), '/'];
	mkdir(directory);
	for i = 1:size(bovws, 1)
		bovw = bovws(i,:);

		bovw2 = [];
		for j=1:k
			for n=1:bovw(j)
				bovw2 = [bovw2, j];
			end
		end
		
		img2 = ibovw_reconstructor_reconstruct(reconstructor, bovw2);
		filename = [directory, num2str(i), '.jpg'];
		imwrite(img2, filename);
	end
end
