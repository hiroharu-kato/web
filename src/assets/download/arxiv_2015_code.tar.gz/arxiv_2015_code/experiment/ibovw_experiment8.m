function [w] = ibovw_experiment8()
	caltech_directory = './external/dataset/caltech101/';
	directory_output = './out/experiment8/';
	mkdir(directory_output);
	addpath('./external/lib/libsvm/');

	settings = ibovw_settings();
	k = settings.visualword.nums(end);
	reconstructor = ibovw_reconstructor_new(k);
	bovw_others = getfield(load(settings.bovw_database.filename{end}), 'bovw_database');
	bovw_others = bovw_others(1:10000,:);
	
	% make category list
	d = dir(caltech_directory);
	categories = {};
	for i=3:size(d,1)
		categories{i-2} = d(i).name;
	end

	for l=1:size(categories,2)
		directory = [caltech_directory, categories{l}];
		filelist = dir([directory, '/*.jpg']);
		bovw_category = zeros(size(filelist, 1), k);
		for i=1:size(filelist, 1)
			img = imread([directory, '/', filelist(i).name]);
			img = imresize(img, settings.image.size);
			bovw_category(i,:) = ibovw_extract_bovw(img, k);
		end
		model = svmtrain([ones(1,size(bovw_category,1)),-1*ones(1,size(bovw_others,1))]',double([bovw_category;bovw_others]), '-t 0');
		w = (model.sv_coef' * full(model.SVs));
		w(w<0) = 0;

		matlabpool
		for m=1:5
			bovw = w;
			bovw2 = sort(bovw, 'descend');
			for j=1:k
				bovw3 = round(bovw/bovw2(j));
				if sum(bovw3) >= settings.descriptor.num
					break
				end
			end
			bovw4 = [];
			for j=1:k
				for n=1:bovw3(j)
					bovw4 = [bovw4, j];
				end
			end
			r = randperm(sum(bovw3));
			bovw4 = bovw4(r(1:settings.descriptor.num));
			bovw4

			img2 = ibovw_reconstructor_reconstruct(reconstructor, bovw4, true);
			for j=0:10
				lambda = j / 10;
				filename2 = [directory_output, categories{l}, '_', num2str(j/10, '%0.1f'), '_', num2str(m), '.jpg'];
				imwrite(img2{j+1}, filename2);
			end
		end
		matlabpool close
	end
end
