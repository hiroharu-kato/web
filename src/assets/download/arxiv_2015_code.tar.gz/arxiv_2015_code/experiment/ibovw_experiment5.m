function ibovw_experiment5()
	settings = ibovw_settings();

	lambda = 0.8;
	directory_original = './external/dataset/original/';
	directory_output = './out/experiment5/';
	mkdir(directory_output);

	filename = dir([directory_original, '*.jpg']);
	pca = load(settings.descriptor.filename_pca);
	k = settings.visualword.nums(end);
	reconstructor = ibovw_reconstructor_new(k);
	reconstructor.lambda = lambda;

	for i=1:size(filename, 1)
		img = imread([directory_original, filename(i).name]);
		[~, codenumbers] = ibovw_extract_bovw(img, k);

		matlabpool(1);
		for j=1:5
			reconstructor.optimization_method = j-1;
			[img, codenumbers2, cost, time] = ibovw_reconstructor_reconstruct(reconstructor, codenumbers);

			f = strsplit(filename(i).name, '.');
			fn = [strjoin(f(1:end-1), '.'), '_m', num2str(j-1)];
			imwrite(img, [directory_output, fn, '.', f{end}]);

			codenumbers_correct = codenumbers;
			codenumbers_reconstructed = codenumbers2;
			save([directory_output, fn, '.mat'], 'codenumbers_correct', 'codenumbers_reconstructed', 'cost', 'time');
		end
		matlabpool close;
	end
end
