function ibovw_experiment4()
	settings = ibovw_settings();

	directory_original = './external/dataset/original/';
	directory_output = './out/experiment4/';
	mkdir(directory_output);

	param.iter=100;
	param.K=1000;
	param.posAlpha=true;
	param.numThreads=-1;
	param.verbose = 1;
	param.mode = 2;
	param.modeD = 0;
	param.batchsize = 400;
	param.lambda = 0.005;
	param.lambda = 0;

	dim = settings.visualword.nums(end);

	if false
		imagelist = getfield(load(settings.dataset.filename_imagelist{1}), 'imagelist');
		Z = uint8(zeros(size(imagelist,2), prod(settings.image.size)+dim));

		parfor i=1:size(imagelist,2)
			i
			img = imread([settings.dataset.directory, imagelist{i}]);
			if ndims(img) == 3
				img = rgb2gray(img);
			end
			bovw = ibovw_extract_bovw(img, settings.visualword.nums(end));
			Z(i,:) = [img(:)', bovw];
		end
		save([directory_output, 'Z'], 'Z');
	end

	if true
		Z = getfield(load([directory_output, 'Z']), 'Z');
		Z = double(Z);

		% normalization
		Z(:,1:end-dim) = Z(:,1:end-dim) -  repmat(mean(Z(:,1:end-dim),2), 1, size(Z(:,1:end-dim),2));
		Z(:,1:end-dim) = Z(:,1:end-dim) ./ repmat(sqrt(sum(Z(:,1:end-dim).^2,2))+eps, 1, size(Z(:,1:end-dim),2));
		Z(:,end-dim+1:end) = Z(:,end-dim+1:end) -  repmat(mean(Z(:,end-dim+1:end),2), 1, size(Z(:,end-dim+1:end),2));
		Z(:,end-dim+1:end) = Z(:,end-dim+1:end) ./ repmat(sqrt(sum(Z(:,end-dim+1:end).^2,2))+eps, 1, size(Z(:,end-dim+1:end),2));

		% dictionary training
		D = mexTrainDL(Z', param)';

		% split and save
		U = D(:,1:end-dim);
		V = D(:,end-dim+1:end);
		save([directory_output, 'UV'], 'U', 'V');
	end

	if true
		UV = load([directory_output, 'UV']);
		
		filename = dir([directory_original, '*.jpg']);

		for i=1:size(filename, 1)
			img = imread([directory_original, filename(i).name]);
			bovw = ibovw_extract_bovw(img, settings.visualword.nums(end));
			bovw = bovw -  repmat(mean(bovw,2), 1, size(bovw,2));
			bovw = bovw ./ repmat(sqrt(sum(bovw.^2,2))+eps, 1, size(bovw,2));
		
			alpha = mexLasso(single(bovw'), single(transpose(UV.V)), param);
			img = transpose(UV.U) * full(alpha);
			img = reshape(img, settings.image.size);
			img(:) = img(:) - min(img(:));
			img(:) = img(:) / max(img(:));
			img = uint8(img*255);
			imwrite(img, [directory_output, filename(i).name]);
		end
	end
end
