function ibovw_experiment9()
	directory_dataset = './external/dataset/PascalSentences/';
	directory_output = './out/experiment9/';
	categories = {'plane', 'boat', 'bus', 'train', 'bottle', 'monitor'};
	location = {'cliff', 'grass', 'field', 'mountain'};

	settings = ibovw_settings();	
	addpath(genpath('./external/lib/MatlabNLP/nlp lib/'));
	mkdir(directory_output);

	k = settings.visualword.nums(end);

	% get filename
	file_image = {};
	file_text = {};
	for i=1:1000
		if exist([directory_dataset, num2str(i), '.jpg']) && exist([directory_dataset, num2str(i), '_nn.txt'])
			file_image{end+1} = [directory_dataset, num2str(i), '.jpg'];
			file_text{end+1} = [directory_dataset, num2str(i), '_nn.txt'];
		end
	end

	% make bag of words
	bows = {};
	for j=1:size(location,2)
		for i=1:size(categories,2)
			bows{(i-1)*(size(location,2))+j} = {categories{i}, location{j}};
		end
	end

	% make word list contained in each sentence
	words = {};
	parfor i=1:size(file_image, 2)
		w = strsplit(regexprep(fileread(file_text{i}), '\n', ' '), ' ');
		for j=1:size(w, 2)
			w{j} = porterStemmer(w{j});
		end
		words{i} = w;
	end

	% extract bovw in the dataset
	bovws = zeros(size(file_image,2), k);
	parfor i=1:size(file_image,2)
		bovws(i,:) = ibovw_extract_bovw(imresize(imread(file_image{i}), settings.image.size), k);
	end

	reconstructor = ibovw_reconstructor_new(k);
	for m=1:size(bows, 2)
		target_words = bows{m};
		bovws2 = zeros(size(target_words, 2), k);
		num_elements = repmat(round(settings.descriptor.num/size(target_words,2)), 1, size(target_words, 2));
		num_elements(end) = settings.descriptor.num-sum(num_elements(1:end-1));

		for i=1:size(target_words, 2)
			word = porterStemmer(target_words{i});
			c = [];
			for j=1:size(file_image,2)
				c(j) = sum(cell2mat(strfind(words{j}, word)))/size(words{j}, 2);
			end
			cc = [];
			for j=1:k
				ccc = corrcoef(c', bovws(:,j)');
				cc(j) = ccc(1,2);
			end
			cc(isnan(cc)) = 0;
			cc(isinf(cc)) = 0;
			cc(cc<0) = 0;

			bovw = cc;
			bovw2 = sort(bovw, 'descend');
			for j=1:k
				bovw3 = round(bovw/bovw2(j));
				if sum(bovw3) >= num_elements(i)
					break
				end
			end
			if (sum(isinf(bovw3)) ~= 0) || (sum(isnan(bovw3)) ~= 0)
				continue
			end
			bovw4 = [];
			for j=1:k
				for n=1:bovw3(j)
					bovw4 = [bovw4, j];
				end
			end
			r = randperm(sum(bovw3));
			bovw4 = bovw4(r(1:num_elements(i)));
			bovws2(i,:) = histc(bovw4, 1:k);

		end

		b = sum(bovws2);
		% if sum(b) ~= sum(num_elements)
		%	continue
		%end
		bovw = [];
		for j=1:k
			for n=1:b(j)
				bovw = [bovw, j];
			end
		end

		img = ibovw_reconstructor_reconstruct(reconstructor, bovw);
		filename = [directory_output, strjoin(target_words, '_'), '.jpg'];
		imwrite(img, filename);
	end
end
