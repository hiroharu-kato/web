function ibovw_experiment1()
	settings = ibovw_settings();

	directory_original = './external/dataset/original/';
	directory_output = './out/experiment1/';
	mkdir(directory_output);
	filename = dir([directory_original, '*.jpg']);
	pca = load(settings.descriptor.filename_pca);
	parfor i=1:size(filename, 1)
		img = imread([directory_original, filename(i).name]);
		d = ibovw_extract_descriptors(img)*pca.coeff;
		d = d(:,1:pca.dim);
		p = ibovw_invertdescriptor_invert(d);
		img2 = ibovw_patches_to_image_average(p);
		imwrite(img2, [directory_output, filename(i).name]);
		for j=1:size(settings.visualword.nums, 2)
			k = settings.visualword.nums(j);
			visualword = getfield(load(settings.visualword.filename{j}), 'visualwords');
			[~, d2] = ibovw_quantize_descriptors(d, visualword);
			p = ibovw_invertdescriptor_invert(d2);
			img2 = ibovw_patches_to_image_average(p);

			f = strsplit(filename(i).name, '.');
			imwrite(img2, [directory_output, strjoin(f(1:end-1), '.'), '_k', num2str(k), '.', f{end}]);
		end
	end
end
