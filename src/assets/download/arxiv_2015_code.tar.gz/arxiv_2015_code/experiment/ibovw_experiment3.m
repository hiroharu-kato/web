function ibovw_experiment3()
	settings = ibovw_settings();

	directory_original = './external/dataset/original/';
	directory_output = './out/experiment3/';
	mkdir(directory_output);

	bovw_database = getfield(load(settings.bovw_database.filename{end}), 'bovw_database');
	bovw_database = sparse(double(bovw_database));
	imagelist = getfield(load(settings.dataset.filename_imagelist{end}), 'imagelist');
	filename = dir([directory_original, '*.jpg']);
	for i=1:size(filename, 1)
		img = imread([directory_original, filename(i).name]);
		bovw = ibovw_extract_bovw(img, settings.visualword.nums(end));
		bovw = sparse(bovw);
		b = bovw_database - repmat(bovw, size(bovw_database, 1), 1);
		b = sum(b.^2, 2)';
		[~, indices] = sort(b);
		img = imread([settings.dataset.directory, imagelist{indices(1)}]);
		imwrite(img, [directory_output, filename(i).name]);
	end
end
