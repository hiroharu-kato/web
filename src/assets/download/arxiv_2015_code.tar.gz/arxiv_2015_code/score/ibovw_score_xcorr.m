function [xcorr, xcorr4, xcorr8] = ibovw_score_xcorr(img1, img2)
	diff = [0, 8, 16];
	score = zeros(size(diff));

	if ndims(img1) == 3
		img1 = rgb2gray(img1);
	end
	if ndims(img2) == 3
		img2 = rgb2gray(img2);
	end

	img1 = im2single(img1);
	img2 = im2single(img2);
	
	for i=1:size(diff,2)
		shift = diff(i);
		score(i) = -intmax;
		for yshift=-shift:shift; for xshift=-shift:shift;
			img1_ = img1(1+shift+yshift:end-shift+yshift,1+shift+xshift:end-shift+xshift);
			img2_ = img2(1+shift:end-shift,1+shift:end-shift);
			c = corrcoef(img1_(:)',img2_(:)');
			score(i) = max(score(i), c(1,2));
		end; end;
	end
	xcorr = score(1);
	xcorr4 = score(2);
	xcorr8 = score(3);
end
