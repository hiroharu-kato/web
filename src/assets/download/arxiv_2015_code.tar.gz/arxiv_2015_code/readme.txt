* About this archive
** This archive contains all codes to have been used to produce all results in the paper "Image Reconstruction from Bag-of-Visual-Words" available at http://hiroharu-kato.com/
** This archive does not contain datasets to be used to obtain parameters.

* Usage

** Initialize
*** Run ibovw_init(); on Matlab. This command arranges image dataset, collect local descriptors, apply PCA, obtain parameters for HOGgles, make visual word dictionary, create a local descriptor and BoVW database, and compute local adjacency cost and global location cost. This takes 2-3 days on a workstation.

** Reconstruct an image from a BoVW
*** Run following commands on the Matlab for example.
**** % path configuration
**** addpath(pathdef)
**** 
**** % load settings
**** settings = ibovw_settings();
**** k = settings.visualword.nums(end);
**** img_size = settings.image.size;
**** 
**** % extract bovw
**** img = imread('test.jpg');
**** img = imresize(img, img_size);
**** [~, bovw] = ibovw_extract_bovw(img, k);
**** 
**** % reconstruction
**** reconstructor = ibovw_reconstructor_new(k);
**** img2 = ibovw_reconstructor_reconstruct(reconstructor, bovw);
**** 
*** All hyper-parameters are defined in ibovw_settings.m.

** Reproduce results in the paper
*** Codes in "experiment" directory are for experiments described in the paper.
**** ibovw_experiment1.m is for Figure 3.
**** ibovw_experiment2.m is for Figure 2 (b), Figure 6, and Figure 9.
**** ibovw_experiment3.m is for Figure 2 (d).
**** ibovw_experiment4.m is for Figure 2 (c).
**** ibovw_experiment5.m is for Table 3.
**** ibovw_experiment6.m is for Table 1, Table 3, Figure 4, Figure 6, and Figure 7.
**** ibovw_experiment7.m is for Figure 10.
**** ibovw_experiment8.m is for Figure 11.
**** ibovw_experiment9.m is for Figure 12.

* Contact
** Please visit http://hiroharu-kato.com/ to access other materials.
** Please email to hiroharu.kato.1989.10.13@gmail.com

