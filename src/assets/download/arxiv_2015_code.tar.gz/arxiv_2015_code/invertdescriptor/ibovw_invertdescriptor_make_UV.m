function [] = rc_invertdescriptor_make_UV()
	% make UV to invert descriptors
	% U(ROW,:) = typical image
	% V(ROW,:) = corresponding descriptor

	settings = ibovw_settings();
	dim = getfield(load(settings.descriptor.filename_pca), 'dim');
	imagesize = settings.descriptor.patchsize^2;

	Z = getfield(load(settings.invertdescriptor.filename_Z), 'Z');

	% use 1/10 for computational complexity
	if size(Z, 1)>1000000
		Z = Z(1:10:1000000,:);
	end

	% normalization
	Z(:,1:end-dim) = Z(:,1:end-dim) -  repmat(mean(Z(:,1:end-dim),2), 1, size(Z(:,1:end-dim),2));
	Z(:,1:end-dim) = Z(:,1:end-dim) ./ repmat(sqrt(sum(Z(:,1:end-dim).^2,2))+eps, 1, size(Z(:,1:end-dim),2));
	Z(:,end-dim+1:end) = Z(:,end-dim+1:end) -  repmat(mean(Z(:,end-dim+1:end),2), 1, size(Z(:,end-dim+1:end),2));
	Z(:,end-dim+1:end) = Z(:,end-dim+1:end) ./ repmat(sqrt(sum(Z(:,end-dim+1:end).^2,2))+eps, 1, size(Z(:,end-dim+1:end),2));
	Z = double(Z);

	% dictionary training
	D = mexTrainDL(Z', settings.invertdescriptor.param)';

	% split and save
	U = D(:,1:end-dim);
	V = D(:,end-dim+1:end);
	save(settings.invertdescriptor.filename_UV, 'U', 'V');
end
