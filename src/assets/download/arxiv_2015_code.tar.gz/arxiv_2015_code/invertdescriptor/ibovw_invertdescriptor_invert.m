function [patches] = ibovw_indertdescriptor_invert(descriptors)
	settings = ibovw_settings();

	UV = load(settings.invertdescriptor.filename_UV);
	patches = zeros(size(descriptors, 1), settings.descriptor.patchsize, settings.descriptor.patchsize, 3);	

	descriptors = descriptors -  repmat(mean(descriptors,2), 1, size(descriptors,2));
	descriptors = descriptors ./ repmat(sqrt(sum(descriptors.^2,2))+eps, 1, size(descriptors,2));
	
	for i = 1:size(descriptors, 1)
		alpha = mexLasso(single(descriptors(i,:)'), single(transpose(UV.V)), settings.invertdescriptor.param);
		img_gen = transpose(UV.U) * full(alpha);
		if settings.descriptor.color
			img_gen = reshape(img_gen, settings.descriptor.patchsize, settings.descriptor.patchsize, 3);
			img_gen(:) = img_gen(:) - min(img_gen(:));
			img_gen(:) = img_gen(:) / max(img_gen(:));
			img_gen = uint8(img_gen*255);
			patches(i,:,:,:) = img_gen;
		else
			img_gen = reshape(img_gen, settings.descriptor.patchsize, settings.descriptor.patchsize);
			img_gen(:) = img_gen(:) - min(img_gen(:));
			img_gen(:) = img_gen(:) / max(img_gen(:));
			img_gen = uint8(img_gen*255);
			patches(i,:,:,:) = repmat(img_gen, [1,1,3]);
		end
	end
end	
